package com.example.awesome_contact_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
