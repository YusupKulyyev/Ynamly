
import 'package:awesome_contact_app/contact_details_view.dart';
import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';

import 'contact_model.dart';

class Homeview extends StatelessWidget {
  Homeview({ Key? key }) : super(key: key);

  final ScrollController _scrollController = ScrollController();

  final List<Map<String,String>>data =
  [
	{
		"name": "Timur Gurbanow",
		"phone": "+993 65 323636",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň direktory orunbasary"
	},
	{
		"name": "Aýperi Garabaýewa",
		"phone": "+993 61 683743",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň kätibi"
	},
	{
		"name": "Meret Gurbanow",
		"phone": "+993 64 011667",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Tehniki gözegçisi"
	},
	{
		"name": "Batyr Amanow",
		"phone": "+993 62 261628",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Marketing bölüminiň başlygy"
	},
	{
		"name": "Rejep Rejepow",
		"phone": "+993 64 180219",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Zähmeti goramak we tehniki howpsuzlygy boýunça hünärmen"
	},
	{
		"name": "Maksat Hojaberdiýew",
		"phone": "+993 62 254848",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Zyýan ýetirmeýän barlag usullary boýunça barlaghananyň başlygy"
	},
	{
		"name": "Orazgylyç Jumaniýazow",
		"phone": "+993 62 090652",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Zyýan ýetirmeýän barlag usullary boýunça barlaghananyň magnit we ultrases gözegçiligi boýunça defektoskopçy"
	},
	{
		"name": "Merdan Amanow",
		"phone": "+993 65 382727",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Zyýan ýetirmeýän barlag usullary boýunça barlaghananyň Inspektory"
	},
	{
		"name": "Ýusup Baýarow",
		"phone": "+993 62 375922",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Üpjünçilik bölüminiň başlygy"
	},
	{
		"name": "Begnepes Saryýew",
		"phone": "+993 64 389939",
		"email": "ynamlyyol@.com.tm",
		"region": "Ynamly ýol hyzmaty HK-nyň Zyýan ýetirmeýän barlag usullary boýunça barlaghananyň Inspektory"
	},
    {
      "name": "Mahmyt Begjanow",
      "phone": "+993 64 870009",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Üpjünçilik bölüminiň Ýükleri gatnatmak boýunça ekspeditory"
    },
    {
      "name": "Eziz Esenow",
      "phone": "+993 64 833233",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Üpjünçilik bölüminiň Ammarçysy"
    },
    {
      "name": "Aşyrmuhammet Gummanow",
      "phone": "+993 65 159922",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Tehnika we ulaglar bölüminiň awtobus sürüjisi"
    },
    {
      "name": "Amantagan Begjanow",
      "phone": "+993 61 110200",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Tehnika we ulaglar bölüminiň ýeňil awtoulag sürüjisi"
    },
    {
      "name": "Durdy Gylyjow",
      "phone": "+993 65 907191",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Tehnika we ulaglar bölüminiň ýeňil awtoulag sürüjisi"
    },
    {
    "name": "Amanmyrat Gurdow",
    "phone": "+993 65 540088",
    "email": "ynamlyyol@.com.tm",
    "region": "Ynamly ýol hyzmaty HK-nyň Tehniki hyzmat we abatlaýyş bölüminiň başlygy"
  },
    {
      "name": "Amanmämmet Satlykow",
      "phone": "+993 64 638818",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Tehniki hyzmat we abatlaýyş bölüminiň hasaplaýjysy"
    },
    {
      "name": "Emin Eminow",
      "phone": "+993 65 164763",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Tehniki hyzmat we abatlaýyş bölüminiň inženeri"
    },
    {
      "name": "Begenç Seýidow",
      "phone": "+993 64 929977",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Tehniki hyzmat we abatlaýyş bölüminde kateriň kapitany"
    },
    {
      "name": "Ýagmyr Babaýew",
      "phone": "+993 61 181841",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Tehniki hyzmat we abatlaýyş bölüminde kateriň kapitany"
    },
    {
      "name": "Aşyrtagan Amanberdiýew",
      "phone": "+993 65 389989",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Keşbirleýjiler toparynyň slesar gurnaýjysy"
    },
    {
      "name": "Stambul Aga-Zade",
      "phone": "+993 61 129569",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Keşbirleýjiler toparynyň Slesar-ektrogaz bilen kebşirleýjisi"
    },
    {
      "name": "Suradj Pirjanow",
      "phone": "+993 62 760381",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Keşbirleýjiler toparynyň Slesar-ektrogaz bilen kebşirleýjisi"
    },
    {
      "name": "Gaşgar Salaýew",
      "phone": "+993 62 476937",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Mehaniki abatlaýyş toparynyň Enjamlary abatlamak boýunça mehanigi"
    },
    {
      "name": "Roman Gorýaçew",
      "phone": "+993 61 371122",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Mehaniki abatlaýyş toparynyň Enjamlara hyzmat we remont ediji slesar"
    },
    {
      "name": "Berdimyrat Seýitjanow",
      "phone": "+993 62 608323",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Mehaniki abatlaýyş toparynyň Enjamlara hyzmat we remont ediji slesar"
    },
    {
      "name": "Sapargylyç Gaýypow",
      "phone": "+993 65 295337",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Mehaniki abatlaýyş toparynyň işçisi"
    },
    {
      "name": "Arzuw Aşyrow",
      "phone": "+993 61 417809",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Mehaniki abatlaýyş toparynyň işçisi"
    },
    {
      "name": "Gurbýat Rasulow",
      "phone": "+993 65 399299",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Mehaniki abatlaýyş toparynyň işçisi"
    },
    {
      "name": "Aleksandr Jumaýew",
      "phone": "+993 63 038150",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Mehaniki abatlaýyş toparynyň işçisi"
    },
    {
      "name": "Wasiliý Sergeýenko",
      "phone": "+993 63 685543",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Elektronawigasiýa we BÖA we A toparynyň Elektrik enjamlaryny abatlamak boýunça slesar-elektrik"
    },
    {
      "name": "Batyr Baýramdurdyýew",
      "phone": "+993 64 983333",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Halas ediş serişdeleri boýunça stansiýanyň başlygy"
    },
    {
      "name": "Meýlis Aýazow",
      "phone": "+993 65 649351",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Halas ediş serişdeleri boýunça stansiýanyň başlygynyň orunbasary"
    },
    {
      "name": "Begenç Waliýew",
      "phone": "+993 64 706050",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Halas ediş serişdelerine hyzmat edýän inžener"
    },
    {
      "name": "Mihail Salýutin",
      "phone": "+993 65 841816",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Halas ediş serişdelerine hyzmat edýän işçi"
    },
    {
      "name": "Oraztagan Taganow",
      "phone": "+993 71 162202",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Halas ediş serişdelerine hyzmat edýän işçi"
    },
    {
      "name": "Umut Uzow",
      "phone": "+993 63 707875",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Halas ediş serişdelerine hyzmat edýän işçisi"
    },
    {
      "name": "Didar Aşyrgulyýew",
      "phone": "+993 65 795256",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Halas ediş serişdeleri boýunça stansiýanyň garawuly"
    },
    {
      "name": "Aýtmammedowa Şirin",
      "phone": "+993 63 689207",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Üpjünçilik bölüminiň üpjünçilik boýunça ekspeditory"
    },
    {
      "name": "Ýusup Orazgulyýew",
      "phone": "+993 62 974674",
      "email": "yusupkulyyew19@gmail.com",
      "region": "Ynamly ýol hyzmaty HK-nyň Sanly bölüminiň programmisty"
    },
    {
      "name": "Aýgözel Hojaýewa",
      "phone": "+993 64 048138",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Sanly bölüminiň programmisty"
    },
    {
      "name": "Kümüş Täçmämmedowa",
      "phone": "+993 64 048138",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Marketing bölüminiň hünärmeni"
    },
    {
      "name": "Jemile Mämmedowa",
      "phone": "+993 64 330888",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Buhgalteri"
    },
    {
      "name": "Baýrambagt Durdyýewa",
      "phone": "+993 65 151834",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Hukukçy"
    },
    {
      "name": "Karina Gabriýelýan",
      "phone": "+993 64 384526",
      "email": "ynamlyyol@.com.tm",
      "region": "Ynamly ýol hyzmaty HK-nyň Marketing bölüminiň hünärmeni"
    }
];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: false,
        title: const Text('Ynamly Ýol Hyzmaty' ,style: TextStyle(fontSize: 24,fontWeight: FontWeight.w600,
        color: Colors.black),),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 10),
            child: Center(
              child: CircleAvatar(radius: 25,
              backgroundImage: AssetImage('assets/avatary.png'),),
            ),
          )

        ],
        elevation: 0,
        backgroundColor: Colors.white,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 5),
          child: TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15)),
                hintText: 'Ady ýa-da belgisi boýunça gözläň',
                prefixIcon: const Icon(Icons.search)
          ),

        ),
        ),
      ),
     ),
     body: SafeArea(
       child: ListView(
       controller: _scrollController,
       children: [
       const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text('Esasy',
           style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
           ),
        ),
       ListView.separated(
         controller: _scrollController,
         shrinkWrap: true,
         itemBuilder: (context,index){
            return  ListTile(
              onTap: (){
Navigator.push(context, MaterialPageRoute(builder: (context){
  return ContactDetailsView(contact: Contact(email: 'naanaa@gmail.com',
  name: 'Bäşimmyrat Ballarow',
  phone: '+993 65 702954',
  region: '"Ynamly ýol hyzmaty" \n HK-nyň Baş inženeri'));
}));
              },
           leading: const CircleAvatar(
             radius: 25,
             backgroundImage: AssetImage('assets/avatary.jpg'),
           ),
           title: const Text(
             'Bäşimmyrat Ballarow',
             style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
           ),
           subtitle: const Text('+993 65 702954'),
           trailing: const IconButton(onPressed: null, icon: Icon(Icons.more_horiz)),
         );
           },
           separatorBuilder: (context,index){
             return  const Divider(
           indent: 25,
           thickness: 2,
             );
           },
           itemCount: 1),
           const Padding(
             padding: EdgeInsets.symmetric(horizontal: 16),
             child: Text('Contacts',
             style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),),
           ),
           GroupedListView<Map<String,String>,String>(
             shrinkWrap: true,
             elements:data,
    groupBy: (element) => element['name'].toString().substring(0,1),
    groupSeparatorBuilder: (String groupByValue) =>
    SizedBox(
      width: MediaQuery.of(context).size.width,
      child: Padding(
        padding:const EdgeInsets.symmetric(horizontal: 16),
        child: Text(
          groupByValue.substring(0,1),
          textAlign: TextAlign.right,
          style:
          const TextStyle(fontWeight: FontWeight.w600, fontSize: 18 ),
          ),
      ),
      ),
    itemBuilder: (context, Map<String,String> element) {
      Contact contact = Contact.fromJson(element);
      return Column(
      children: [
        ListTile(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context){
           return ContactDetailsView(contact: contact,);
           },));
          },
               leading: const CircleAvatar(
                 radius: 25,
                 backgroundImage: AssetImage('assets/avatary.png'),
               ),
               title: Text(
                 '${element['name']}',
                 style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
               ),
              subtitle: Text('${element['phone']}'),
              trailing:
               const IconButton(onPressed: null, icon: Icon(Icons.more_horiz),),),
              const Divider(
           indent: 25,
           thickness: 2,
              )
      ],
    );
    },

    itemComparator: (item1, item2) =>
    item1['name']!.compareTo(item2['name']!), // optional
    useStickyGroupSeparators: true, // optional
    floatingHeader: true, // optional
    order: GroupedListOrder.ASC, // optional
  ),
       ],
     ),
     ),
     floatingActionButton: const FloatingActionButton(
       backgroundColor: Color(0xff1A4ADA),
       onPressed: null,
       child: Icon(Icons.add),),
        );
  }
}