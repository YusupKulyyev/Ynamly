import 'package:awesome_contact_app/contact_model.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactDetailsView extends StatelessWidget {
  const ContactDetailsView({Key? key, required this.contact}) : super(key: key);

  final Contact contact;

  // === ФУНКЦИИ ДЛЯ ВЫЗОВА, SMS и EMAIL ===
  void _callNumber(String phoneNumber) async {
    final Uri url = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      debugPrint('❌ Не удалось позвонить на $phoneNumber');
    }
  }

  void _sendSms(String phoneNumber) async {
    final Uri url = Uri(scheme: 'sms', path: phoneNumber);
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      debugPrint('❌ Не удалось отправить SMS на $phoneNumber');
    }
  }

  void _sendEmail(String email) async {
    final Uri url = Uri(scheme: 'mailto', path: email);
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      debugPrint('❌ Не удалось отправить Email на $email');
    }
  }

  // === ОСНОВНОЙ UI ===
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8FB),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'Contact',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600, color: Colors.black),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.more_vert),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 60,
              backgroundImage: AssetImage('assets/avataring.jpg'),
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text(
              contact.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              contact.region,
              style: const TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
              softWrap: true,
            ),
          ),
          const SizedBox(height: 24),
          _buildSectionCard([
            ListTile(
              title: const Text('Mobile', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
              subtitle: Text(
                contact.phone,
                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextButton(
                    onPressed: () {
                      _sendSms(contact.phone);
                    },
                    child: const Icon(Icons.message, color: Colors.black),
                    style: TextButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: const CircleBorder(),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      _callNumber(contact.phone);
                    },
                    child: const Icon(Icons.call, color: Colors.black),
                    style: TextButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: const CircleBorder(),
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              title: const Text('Email', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
              subtitle: Text(
                contact.email,
                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
              ),
              trailing: TextButton(
                onPressed: () {
                  _sendEmail(contact.email);
                },
                child: const Icon(Icons.email, color: Colors.black),
                style: TextButton.styleFrom(
                  backgroundColor: Colors.white,
                  shape: const CircleBorder(),
                ),
              ),
            ),
          ]),
          const SizedBox(height: 20),
          const Padding(
            padding: EdgeInsets.only(left: 8),
            child: Text('Account Linked',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
          ),
          _buildSectionCard([
            ListTile(
              title: const Text('Telegram', style: TextStyle(fontSize: 16)),
              trailing: Image.asset('assets/telegram.png', height: 24),
            ),
            ListTile(
              title: const Text('WhatsApp', style: TextStyle(fontSize: 16)),
              trailing: Image.asset('assets/whatsapp.png', height: 24),
            ),
          ]),
          const SizedBox(height: 20),
          const Padding(
            padding: EdgeInsets.only(left: 8),
            child: Text('More Options',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
          ),
          _buildSectionCard([
            const ListTile(
              title: Text('Share Contact', style: TextStyle(fontSize: 16)),
            ),
            const ListTile(
              title: Text('QR Code', style: TextStyle(fontSize: 16)),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildSectionCard(List<Widget> children) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xffe7edf4),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(children: children),
    );
  }
}
